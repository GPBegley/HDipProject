create table Clients
(
Client_ID nchar(10),
ContactFirstName nchar(50),
ContactLastName nchar(50),
JobTitle nchar(30),
PublisherName nchar(30),
Address1 nchar(20),
Address2 nchar(20),
City nchar(20),
Country nchar(20),
PostCode nchar(10),
PhoneNo nchar(12),
Website nchar(30),
Email nchar(30)
);
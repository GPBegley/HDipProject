use BookEnds;
GO

CREATE PROCEDURE spGetPublisherDetails
AS
SELECT PublisherName, Address1, Address2, City, Country, PostCode
FROM Clients
ORDER BY PublisherName;

EXEC spGetPublisherDetails;
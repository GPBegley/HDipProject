USE BookEnds;

INSERT INTO BooksIndexed(Book_ID, Book_Name, Author_Name, Publisher, Subject, ISBN, Year)
VALUES(298, 'Irish Fine Art', 'Fenlon', 'Irish Academic Press', 'Art',NULL, 2016);
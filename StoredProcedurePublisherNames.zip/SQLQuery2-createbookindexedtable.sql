use  BookEnds

create table BooksIndexed
(
Book_ID nchar(10),
Book_Name nchar(50),
Author_Name nchar(50),
Publisher nchar(30),
Subject nchar(30),
ISBN nchar(20),
Year date,
);


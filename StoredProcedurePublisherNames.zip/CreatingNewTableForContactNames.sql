CREATE TABLE contactNames
(Name_ID int identity not null,
First_Name char(30) not null,
Last_Name char(30) not null,
Email varchar(30) not null,
CompanyName char(30) not null,
Description varchar(80) null);

make table Books_Indexed
